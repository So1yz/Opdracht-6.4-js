function calculate(nummer1, nummer2)
{
    let resultaat = nummer1 + nummer2;
    console.log(resultaat);
}

calculate(5, 10);


function calculate2(nummer3)
{
    let resultaat2 = nummer3 * 5;
    console.log(resultaat2);
}

calculate2(4);

function calculateminutes(seconden)
{
    let minute = seconden / 60;
    console.log(minute);
}

calculateminutes(3600);
